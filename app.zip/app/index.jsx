import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import { HomePage } from './screen'

const App = (props) => {
    return(
       <HomePage/>
    )
}
export default App