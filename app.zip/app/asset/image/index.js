import Logo from './Logo.png'
import Logo1 from './Logo1.png'
import LangEn from './Lang-en.png'
import Plane1 from './Plane1.png'
import Plane2 from './Plane2.png'
import Plane3 from './Plane3.png'
import Plane4 from './Plane4.png'
import Building from './Building.png'
import Building2 from './Building2.png'
import Ballon from './Ballon.png'
import Ballon2 from './Ballon2.png'
import Banner1 from './Banner1.png'
import Banner2 from './Banner2.png'
import Banner3 from './Banner3.png'
import Car from './Car.png'
import Car2 from './Car2.png'
import Car3 from './Car3.png'
import Car4 from './Car4.png'
import Calendar from './Calendar.png'
import Profile from './Profile.png'
import Percent from './Percent.png'

export default {
  Logo,
  Logo1,
  LangEn,
  Plane1,
  Plane2,
  Plane3,
  Plane4,
  Building,
  Building2,
  Ballon,
  Ballon2,
  Banner1,
  Banner2,
  Banner3,
  Car,
  Car2,
  Car3,
  Car4,
  Calendar,
  Profile,
  Percent
}